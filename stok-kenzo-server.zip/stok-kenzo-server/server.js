'use strict';
// Server stok Kenzo (SQLite). Butuh Node.js 22.13+ (memakai node:sqlite bawaan, tanpa npm install).
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const {DatabaseSync}=require('node:sqlite');
try{fs.readFileSync(path.join(__dirname,'.env'),'utf8').split('\n').forEach(l=>{const m=/^\s*([A-Z_]+)\s*=\s*(.*)\s*$/.exec(l);if(m&&!(m[1] in process.env))process.env[m[1]]=m[2];});}catch(e){}
const PORT=+process.env.PORT||3000,DATA=path.resolve(process.env.DATA_DIR||path.join(__dirname,'data')),PUB=path.join(__dirname,'public');
fs.mkdirSync(path.join(DATA,'backup'),{recursive:true});
const db=new DatabaseSync(path.join(DATA,'stok.db'));
db.exec(`PRAGMA journal_mode=WAL;PRAGMA synchronous=NORMAL;PRAGMA busy_timeout=5000;
CREATE TABLE IF NOT EXISTS items(id TEXT PRIMARY KEY,data TEXT NOT NULL,ver INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS menus(id TEXT PRIMARY KEY,data TEXT NOT NULL,ver INTEGER NOT NULL);
CREATE TABLE IF NOT EXISTS log(id INTEGER PRIMARY KEY AUTOINCREMENT,data TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS kv(k TEXT PRIMARY KEY,v TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS users(username TEXT PRIMARY KEY,name TEXT NOT NULL,role TEXT NOT NULL,salt TEXT NOT NULL,hash TEXT NOT NULL);
CREATE TABLE IF NOT EXISTS sessions(token TEXT PRIMARY KEY,username TEXT NOT NULL,exp INTEGER NOT NULL);`);
const q=s=>db.prepare(s);
const getKV=k=>{const r=q('SELECT v FROM kv WHERE k=?').get(k);return r?JSON.parse(r.v):null;};
const setKV=(k,v)=>q('INSERT INTO kv(k,v) VALUES(?,?) ON CONFLICT(k) DO UPDATE SET v=excluded.v').run(k,JSON.stringify(v));
const getRev=()=>getKV('rev')||0;
const hp=(pw,salt)=>crypto.scryptSync(pw,salt,64).toString('hex');
function addUser(u,name,pw,role){const salt=crypto.randomBytes(16).toString('hex');q('INSERT INTO users(username,name,role,salt,hash) VALUES(?,?,?,?,?)').run(u,name||u,role||'staff',salt,hp(pw,salt));}
if(!q('SELECT COUNT(*) c FROM users').get().c){
  const u=process.env.ADMIN_USER||'owner',pw=process.env.ADMIN_PASS||crypto.randomBytes(6).toString('base64url');
  addUser(u.toLowerCase(),'Owner',pw,'owner');
  console.log('\n=== AKUN OWNER DIBUAT ===\nUsername: '+u+'\nPassword: '+pw+'\nSimpan password ini, lalu ganti lewat menu Kelola staf.\n');
}
if(!q('SELECT COUNT(*) c FROM items').get().c){
  try{const d=JSON.parse(fs.readFileSync(path.join(__dirname,'seed','state.json'),'utf8'));
    db.exec('BEGIN');const ii=q('INSERT INTO items(id,data,ver) VALUES(?,?,1)'),mm=q('INSERT INTO menus(id,data,ver) VALUES(?,?,1)'),ll=q('INSERT INTO log(data) VALUES(?)');
    (d.items||[]).forEach(x=>ii.run(String(x.id),JSON.stringify(x)));(d.menus||[]).forEach(x=>mm.run(String(x.id),JSON.stringify(x)));(d.log||[]).forEach(x=>ll.run(JSON.stringify(x)));
    setKV('rev',1);db.exec('COMMIT');console.log('Data awal dimuat dari seed/state.json ('+(d.items||[]).length+' bahan)');}
  catch(e){try{db.exec('ROLLBACK')}catch(x){}}
}
function fullState(){
  const rows=t=>q('SELECT id,data,ver FROM '+t+' ORDER BY rowid').all(),vers={items:{},menus:{}};
  const mk=t=>rows(t).map(r=>{vers[t][r.id]=r.ver;return JSON.parse(r.data);});
  const items=mk('items'),menus=mk('menus'),log=q('SELECT data FROM (SELECT id,data FROM log ORDER BY id DESC LIMIT 500) ORDER BY id').all().map(r=>JSON.parse(r.data));
  return {exists:true,data:{items,menus,log},vers,rev:getRev()};
}
function sync(b){
  const conf=[],nv={items:{},menus:{}};
  db.exec('BEGIN IMMEDIATE');
  try{
    for(const t of ['items','menus']){const s=(b&&b[t])||{};
      for(const u of (s.up||[])){const id=String(u.id),r=q('SELECT ver FROM '+t+' WHERE id=?').get(id),cur=r?r.ver:0;
        if(cur!==(+u.base||0)){conf.push(t+':'+id);continue;}
        q('INSERT INTO '+t+'(id,data,ver) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data,ver=excluded.ver').run(id,JSON.stringify(u.data),cur+1);nv[t][id]=cur+1;}
      for(const d of (s.del||[])){const id=String(d.id),r=q('SELECT ver FROM '+t+' WHERE id=?').get(id);
        if(r&&r.ver!==(+d.base||0)){conf.push(t+':'+id);continue;}if(r)q('DELETE FROM '+t+' WHERE id=?').run(id);}}
    if(conf.length){db.exec('ROLLBACK');return {conflict:true};}
    const ll=q('INSERT INTO log(data) VALUES(?)');for(const l of ((b&&b.log&&b.log.add)||[]))ll.run(JSON.stringify(l));
    q('DELETE FROM log WHERE id<=(SELECT MAX(id)-20000 FROM log)').run();
    const rev=getRev()+1;setKV('rev',rev);db.exec('COMMIT');return {ok:true,rev,vers:nv};
  }catch(e){try{db.exec('ROLLBACK')}catch(x){}throw e;}
}
function backup(){try{const f=path.join(DATA,'backup','stok-'+new Date().toISOString().slice(0,10)+'.db');
  if(!fs.existsSync(f))db.exec("VACUUM INTO '"+f.replace(/'/g,"''")+"'");
  fs.readdirSync(path.join(DATA,'backup')).filter(n=>/^stok-.*\.db$/.test(n)).sort().slice(0,-30).forEach(n=>fs.unlinkSync(path.join(DATA,'backup',n)));}catch(e){console.log('Cadangan gagal:',e.message);}}
backup();setInterval(backup,36e5);
const secure=req=>process.env.COOKIE_SECURE==='1'||req.headers['x-forwarded-proto']==='https';
const cookies=req=>Object.fromEntries((req.headers.cookie||'').split(';').map(c=>c.trim().split('=')).filter(a=>a[0]).map(a=>[a[0],decodeURIComponent(a.slice(1).join('='))]));
function who(req){const t=cookies(req).sid;if(!t)return null;const s=q('SELECT s.username,s.exp,u.name,u.role FROM sessions s JOIN users u ON u.username=s.username WHERE s.token=?').get(t);
  if(!s||s.exp<Date.now())return null;return {username:s.username,name:s.name,role:s.role};}
const fails={};
function json(res,code,o,h){res.writeHead(code,Object.assign({'Content-Type':'application/json','Cache-Control':'no-store'},h||{}));res.end(JSON.stringify(o));}
function body(req){return new Promise((ok,no)=>{let b='',n=0;req.on('data',c=>{n+=c.length;if(n>4e6){no(new Error('besar'));req.destroy();}else b+=c;});req.on('end',()=>{try{ok(b?JSON.parse(b):{})}catch(e){no(e)}});});}
const MIME={'.html':'text/html; charset=utf-8','.js':'text/javascript','.css':'text/css','.mp4':'video/mp4','.png':'image/png','.jpg':'image/jpeg','.svg':'image/svg+xml','.json':'application/json','.ico':'image/x-icon'};
function serve(req,res,file){
  fs.stat(file,(e,st)=>{if(e||!st.isFile()){res.writeHead(404);return res.end('Tidak ditemukan');}
    const ct=MIME[path.extname(file)]||'application/octet-stream',h={'Content-Type':ct,'Accept-Ranges':'bytes','Cache-Control':ct==='video/mp4'?'public, max-age=604800':'no-cache'},rg=req.headers.range;
    if(rg){const m=/bytes=(\d*)-(\d*)/.exec(rg);let a=m[1]?+m[1]:0,b=m[2]?+m[2]:st.size-1;if(!m[1]&&m[2]){a=st.size-(+m[2]);b=st.size-1;}b=Math.min(b,st.size-1);
      if(a>b||a>=st.size){res.writeHead(416,{'Content-Range':'bytes */'+st.size});return res.end();}
      res.writeHead(206,Object.assign(h,{'Content-Range':`bytes ${a}-${b}/${st.size}`,'Content-Length':b-a+1}));return fs.createReadStream(file,{start:a,end:b}).pipe(res);}
    res.writeHead(200,Object.assign(h,{'Content-Length':st.size}));fs.createReadStream(file).pipe(res);});
}
http.createServer(async(req,res)=>{
  const url=new URL(req.url,'http://x'),p=decodeURIComponent(url.pathname);
  try{
    const me=who(req);
    if(p.startsWith('/api/')){
      if(req.method!=='GET'&&!/json/.test(req.headers['content-type']||''))return json(res,415,{error:'Harus JSON'});
      if(p==='/api/login'&&req.method==='POST'){
        const ip=req.socket.remoteAddress,f=fails[ip]||{n:0,t:0};if(f.n>=5&&Date.now()-f.t<6e5)return json(res,429,{error:'Terlalu banyak percobaan. Coba lagi 10 menit lagi.'});
        const b=await body(req),un=String(b.username||'').trim().toLowerCase(),u=q('SELECT * FROM users WHERE username=?').get(un);
        if(!u||hp(String(b.password||''),u.salt)!==u.hash){fails[ip]={n:f.n+1,t:Date.now()};return json(res,401,{error:'Username atau password salah'});}
        delete fails[ip];const t=crypto.randomBytes(24).toString('hex');q('DELETE FROM sessions WHERE exp<?').run(Date.now());
        q('INSERT INTO sessions(token,username,exp) VALUES(?,?,?)').run(t,un,Date.now()+12*864e5);
        return json(res,200,{ok:true},{'Set-Cookie':`sid=${t}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${12*86400}${secure(req)?'; Secure':''}`});}
      if(p==='/api/logout'){const t=cookies(req).sid;if(t)q('DELETE FROM sessions WHERE token=?').run(t);return json(res,200,{ok:true},{'Set-Cookie':'sid=; Max-Age=0; Path=/'});}
      if(!me)return json(res,401,{error:'Belum login'});
      if(p==='/api/me')return json(res,200,me);
      if(p==='/api/rev')return json(res,200,{rev:getRev()});
      if(p==='/api/doc/app/state'&&req.method==='GET')return json(res,200,fullState());
      if(p==='/api/sync'&&req.method==='POST'){const r=sync(await body(req));return r.conflict?json(res,409,{conflict:true,state:fullState()}):json(res,200,r);}
      if(p==='/api/doc/app/pin'){if(req.method==='GET'){const v=getKV('pin');return json(res,200,v?{exists:true,data:v}:{exists:false});}
        if(req.method==='PUT'){if(me.role!=='owner')return json(res,403,{error:'Hanya owner yang boleh mengatur PIN'});setKV('pin',await body(req));return json(res,200,{ok:true});}}
      if(p.startsWith('/api/users')){if(me.role!=='owner')return json(res,403,{error:'Khusus owner'});
        const un=decodeURIComponent(p.slice(11)).toLowerCase(),ex=un&&q('SELECT username FROM users WHERE username=?').get(un);
        if(req.method==='GET'&&!un)return json(res,200,q('SELECT username,name,role FROM users ORDER BY rowid').all());
        if(req.method==='POST'&&!un){const b=await body(req),k=String(b.username||'').trim().toLowerCase();
          if(!/^[a-z0-9._-]{3,30}$/.test(k))return json(res,400,{error:'Username 3-30 karakter: huruf kecil, angka, titik, strip'});
          if(q('SELECT 1 x FROM users WHERE username=?').get(k))return json(res,409,{error:'Username sudah dipakai'});if(String(b.password||'').length<6)return json(res,400,{error:'Password minimal 6 karakter'});
          addUser(k,String(b.name||k).slice(0,40),String(b.password),b.role==='owner'?'owner':'staff');return json(res,200,{ok:true});}
        if(req.method==='PUT'&&ex){const b=await body(req);if(b.name)q('UPDATE users SET name=? WHERE username=?').run(String(b.name).slice(0,40),un);
          if(b.password){if(String(b.password).length<6)return json(res,400,{error:'Password minimal 6 karakter'});const s=crypto.randomBytes(16).toString('hex');q('UPDATE users SET salt=?,hash=? WHERE username=?').run(s,hp(String(b.password),s),un);q('DELETE FROM sessions WHERE username=?').run(un);}
          return json(res,200,{ok:true});}
        if(req.method==='DELETE'&&ex){if(un===me.username)return json(res,400,{error:'Tidak bisa menghapus akun sendiri'});
          if(q('SELECT role FROM users WHERE username=?').get(un).role==='owner'&&q("SELECT COUNT(*) c FROM users WHERE role='owner'").get().c<2)return json(res,400,{error:'Harus ada minimal satu owner'});
          q('DELETE FROM users WHERE username=?').run(un);q('DELETE FROM sessions WHERE username=?').run(un);return json(res,200,{ok:true});}}
      return json(res,404,{error:'Tidak ada'});
    }
    if(p==='/'||p==='/index.html'){if(!me){res.writeHead(302,{Location:'/login.html'});return res.end();}return serve(req,res,path.join(PUB,'index.html'));}
    if(p==='/admin.html'){if(!me||me.role!=='owner'){res.writeHead(302,{Location:me?'/':'/login.html'});return res.end();}return serve(req,res,path.join(PUB,'admin.html'));}
    const f=path.normalize(path.join(PUB,p));if(!f.startsWith(PUB))return json(res,403,{error:'Dilarang'});return serve(req,res,f);
  }catch(e){console.log(e);json(res,500,{error:'Kesalahan server'});}
}).listen(PORT,()=>console.log('Stok Kenzo berjalan di http://localhost:'+PORT+'  (data: '+DATA+')'));
