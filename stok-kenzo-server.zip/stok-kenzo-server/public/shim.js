// Sambungan aplikasi ke server: login, simpan per bahan (tanpa saling menimpa), dan penyegaran otomatis.
(function(){
  var base={items:{},menus:{},log:{}},vers={items:{},menus:{}},rev=0,dirty=0,busy=false;
  async function raw(p,m,b){var r=await fetch(p,{method:m||'GET',credentials:'same-origin',headers:{'Content-Type':'application/json'},body:b?JSON.stringify(b):undefined});
    if(r.status===401){location.href='/login.html';throw new Error('401');}
    var j=await r.json().catch(function(){return{};});return{s:r.status,j:j};}
  async function api(p,m,b){var r=await raw(p,m,b);if(r.s>=400)throw new Error(r.j.error||r.s);return r.j;}
  var key=function(l){return l.t+'|'+l.n+'|'+l.ty+'|'+l.q;};
  function snap(){base={items:{},menus:{},log:{}};
    (S.items||[]).forEach(function(x){base.items[x.id]=JSON.stringify(x);});
    (S.menus||[]).forEach(function(x){base.menus[x.id]=JSON.stringify(x);});
    (S.log||[]).forEach(function(l){base.log[key(l)]=1;});}
  function adopt(d){S.items=d.data.items||[];S.menus=d.data.menus||[];S.log=d.data.log||[];S.items.forEach(ensure);vers=d.vers;rev=d.rev;snap();render();}
  function say(t){try{if(typeof toast==='function')toast(t);}catch(e){}}
  async function push(v){
    var dl={items:{up:[],del:[]},menus:{up:[],del:[]},log:{add:[]}};
    ['items','menus'].forEach(function(k){var cur={};
      (v[k]||[]).forEach(function(x){cur[x.id]=1;if(base[k][x.id]!==JSON.stringify(x))dl[k].up.push({id:x.id,data:x,base:vers[k][x.id]||0});});
      Object.keys(base[k]).forEach(function(id){if(!cur[id])dl[k].del.push({id:id,base:vers[k][id]||0});});});
    (v.log||[]).forEach(function(l){if(!base.log[key(l)])dl.log.add.push(l);});
    if(!dl.items.up.length&&!dl.items.del.length&&!dl.menus.up.length&&!dl.menus.del.length&&!dl.log.add.length)return;
    busy=true;
    try{var r=await raw('/api/sync','POST',dl);
      if(r.s===409){adopt(r.j.state);say('Data baru saja diubah staf lain. Tampilan sudah diperbarui, silakan ulangi.');throw new Error('konflik');}
      if(r.s>=400)throw new Error(r.j.error||r.s);
      ['items','menus'].forEach(function(k){dl[k].up.forEach(function(u){base[k][u.id]=JSON.stringify(u.data);vers[k][u.id]=r.j.vers[k][u.id];});
        dl[k].del.forEach(function(d){delete base[k][d.id];delete vers[k][d.id];});});
      dl.log.add.forEach(function(l){base.log[key(l)]=1;});rev=r.j.rev;
    }finally{busy=false;}}
  window.claude={use:async function(n){
    if(n==='db')return{doc:function(p){return{
      get:async function(){var d=await api('/api/doc/'+p);
        if(p==='app/state'&&d.exists){vers=d.vers;rev=d.rev;setTimeout(snap,0);}
        return{exists:!!d.exists,data:function(){return d.data;}};},
      set:async function(v){if(p==='app/state')return push(v);await api('/api/doc/'+p,'PUT',v);}};}};
    if(n==='user'){var m=await api('/api/me');return{me:async function(){return{id:m.username,name:m.name};},isOwner:function(){return m.role==='owner';},canEdit:function(){return m.role==='owner';}};}
    return null;}};
  async function poll(){try{if(busy||document.hidden||Date.now()-dirty<5000||document.querySelector('.ov.on'))return;
    var r=await api('/api/rev');if(r.rev===rev)return;adopt(await api('/api/doc/app/state'));}catch(e){}}
  window.addEventListener('load',function(){
    var sv=window.save;if(typeof sv==='function')window.save=function(){dirty=Date.now();return sv.apply(this,arguments);};
    setInterval(poll,5000);document.addEventListener('visibilitychange',poll);});
  document.addEventListener('DOMContentLoaded',async function(){
    try{var m=await api('/api/me'),s=document.getElementById('sync');if(!s)return;
      var c=document.createElement('span');c.style.cssText='font-size:.78rem;margin-left:8px;opacity:.9';
      c.innerHTML='· 👤 '+m.name.replace(/[<>&]/g,'')+' · '+(m.role==='owner'?'<a href="/admin.html" style="color:inherit">Kelola staf</a> · ':'')+'<a href="#" id="lgo" style="color:inherit">Keluar</a>';
      s.insertAdjacentElement('afterend',c);
      document.getElementById('lgo').onclick=async function(e){e.preventDefault();await raw('/api/logout','POST',{});location.href='/login.html';};
    }catch(e){}});
})();
