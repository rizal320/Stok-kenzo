# Stok Kenzo – versi server (login staf)

Aplikasi stok bahan baku Kenzo (Kitchen + Bar) yang berjalan di server Anda sendiri.
Staf masuk dengan username dan password masing-masing, tanpa akun Claude. Riwayat stok mencatat nama staf yang bertindak.

Isi paket: `server.js` (database SQLite bawaan Node, tanpa `npm install`, butuh **Node.js 22.13+**), folder `public/` (aplikasi, halaman login, halaman kelola staf, video), `seed/state.json` (190 bahan awal: 156 Kitchen + 34 Bar).

## 1. Coba di komputer sendiri
```
node server.js
```
Saat pertama jalan, layar menampilkan username dan password owner. **Catat password itu.**
Buka http://localhost:3000. Untuk menentukan sendiri: `ADMIN_USER=owner ADMIN_PASS=passwordkuat node server.js`
(hanya dipakai saat pertama kali, ketika belum ada akun).

## 2. Pasang di server (VPS Ubuntu, disarankan)
1. Install Node.js 22.13+ (disarankan versi 22 LTS) dan unggah folder ini, misalnya ke `/opt/stok-kenzo`.
2. Jalankan terus-menerus dengan pm2:
   ```
   npm i -g pm2
   cd /opt/stok-kenzo
   ADMIN_PASS=passwordkuat COOKIE_SECURE=1 pm2 start server.js --name stok
   pm2 save && pm2 startup
   ```
3. Pasang HTTPS (wajib, supaya password staf tidak terbaca di jaringan). Cara termudah dengan Caddy, isi `/etc/caddy/Caddyfile`:
   ```
   stok.domainanda.com {
     reverse_proxy localhost:3000
   }
   ```
   Arahkan DNS domain ke IP server. Caddy mengurus sertifikat otomatis.
4. Bagikan alamat `https://stok.domainanda.com` ke staf. Di HP: buka di browser, menu ⋮ atau Bagikan, lalu **Tambahkan ke layar utama**.

Alternatif tanpa VPS: Railway atau Render (langkah rinci ada di `PANDUAN-HOSTING.md`). Gunakan Dockerfile yang disertakan dan pasang **volume/disk permanen** di `/data`
(tanpa disk permanen, data hilang saat server restart).

## 3. Kelola staf
Masuk sebagai owner, lalu buka **Kelola staf** (tautan kecil di bawah bar status aplikasi, atau `/admin.html`).
- Tambah staf (username, nama tampil, password awal), reset password, hapus akun.
- **Staf**: boleh pakai, masuk, jual, dan catat stok. **Owner**: juga boleh kelola staf dan mengatur PIN kunci layar.
- Reset password atau hapus akun langsung mengeluarkan orang itu dari semua perangkat.
- Login dibatasi 5 kali salah per alamat, lalu terkunci 10 menit.

## 4. Data dan cadangan
Semua data (stok, menu, riwayat, akun staf) ada di satu berkas: `data/stok.db` (atau di `DATA_DIR`).
Salinan harian otomatis dibuat di `data/backup/` (30 hari terakhir disimpan). Salin folder `data/` ke tempat lain secara berkala.
Untuk memulihkan: hentikan server, ganti `stok.db` dengan salah satu berkas cadangan, lalu jalankan lagi.

## 5. Beberapa staf memakai bersamaan
- Perubahan disimpan **per bahan**, bukan seluruh data sekaligus. Dua staf yang mengubah bahan berbeda tidak saling mengganggu.
- Kalau dua staf mengubah **bahan yang sama** pada saat berdekatan, yang kedua ditolak (tidak ada yang ditimpa diam-diam).
  Layarnya otomatis diperbarui dan muncul pesan "Data baru saja diubah staf lain", lalu staf tinggal mengulang input.
  Penolakan berlaku untuk seluruh penyimpanan itu, jadi tidak ada stok yang tersimpan setengah-setengah.
- Aplikasi menyegarkan data tiap 5 detik, jadi perubahan staf lain muncul tanpa muat ulang.
- PIN layar kunci di aplikasi tetap ada sebagai lapisan tambahan dan hanya owner yang bisa mengaturnya.
- Cocok untuk satu cafe dengan beberapa belas staf. Untuk banyak outlet, pindahkan ke database server (mis. Postgres).
