# Panduan pasang: pilih salah satu

Semua cara memakai `Dockerfile` yang sudah ada, supaya versi Node otomatis benar (22).
Yang wajib di semua cara: **penyimpanan permanen** di `/data`, dan **HTTPS** (disediakan otomatis oleh Railway dan Render).
Harga dan menu bisa berubah, jadi cek halaman layanan masing-masing.

## A. Railway (paling mudah)
1. Unggah folder ini ke repositori GitHub (boleh privat).
2. Di railway.app: **New Project > Deploy from GitHub repo**, pilih repositori itu. Railway otomatis memakai Dockerfile.
3. Buka layanan tersebut > **Variables**, tambahkan:
   - `ADMIN_USER` = `owner` (atau nama yang Anda mau)
   - `ADMIN_PASS` = password kuat untuk owner
   - `DATA_DIR` = `/data`
4. Buka **Volumes** (klik kanan di kanvas, atau tombol Add > Volume), buat volume dan pasang di mount path `/data`.
5. Buka **Settings > Networking > Generate Domain**. Alamat itulah yang dibagikan ke staf.
6. Masuk sebagai owner, buka **Kelola staf**, tambah akun staf.

## B. Render (langkah untuk Anda)
Render menyediakan disk permanen hanya untuk layanan **berbayar** (paket Starter ke atas). Paket gratis tidak bisa memasang disk,
jadi data akan hilang setiap restart. Karena itu paket ini disiapkan untuk Starter. Cek harga terbaru di render.com/pricing.

**Cara cepat (memakai `render.yaml` yang sudah ada di paket):**
1. Buat akun di render.com dan sambungkan GitHub.
2. Buat repositori GitHub baru (boleh privat), lalu unggah **seluruh isi folder ini** (`server.js`, `public/`, `seed/`, `Dockerfile`, `render.yaml`, dan lainnya).
   Cara termudah: di halaman repositori kosong pilih **uploading an existing file**, lalu tarik semua berkas dan folder.
3. Di Render: **New > Blueprint**, pilih repositori tadi. Render membaca `render.yaml` dan menyiapkan layanan, disk 1 GB di `/data`, dan variabel.
4. Saat diminta, isi **ADMIN_PASS** dengan password kuat untuk akun owner. Lalu tekan **Apply / Deploy**.
5. Tunggu proses build selesai (beberapa menit). Alamat layanan berbentuk `https://stok-kenzo-xxxx.onrender.com` dan sudah ber-HTTPS.
6. Buka alamat itu, masuk dengan username `owner` dan password tadi, lalu buka **Kelola staf** untuk menambah akun staf.

**Cara manual (tanpa Blueprint):** New > Web Service > pilih repositori > Runtime **Docker** > pilih paket **Starter**.
Tambah variabel `ADMIN_USER`, `ADMIN_PASS`, `DATA_DIR=/data`, `COOKIE_SECURE=1`. Di bagian **Disks**, tambah disk dengan Mount Path `/data`.

**Catatan penting Render**
- `ADMIN_PASS` hanya dipakai sekali, saat akun pertama dibuat. Mengubahnya nanti tidak mengganti password. Gunakan menu **Kelola staf** untuk reset.
- Layanan dengan disk tidak bisa memakai lebih dari satu instance, dan saat deploy ulang ada jeda singkat. Itu wajar untuk aplikasi ini.
- Render membuat snapshot disk tiap 24 jam, dan aplikasi juga menyimpan cadangan harian sendiri di `/data/backup`.
- Hasil akhir dan harga bisa berbeda dari uraian ini karena Render bisa mengubah tampilan atau paketnya.

## C. VPS sendiri (Ubuntu)
Ikuti bagian 2 di `README.md` (pm2 + Caddy untuk HTTPS).

## Setelah terpasang, cek
1. Buka alamatnya di HP: muncul video mobil dengan tulisan _ZAC_ dan form login.
2. Masuk sebagai owner, tambah satu staf, lalu masuk dengan akun staf itu di HP lain.
3. Ubah satu stok di HP staf, dan lihat perubahan muncul di HP owner dalam sekitar 5 detik.
4. Cek bahwa data tetap ada setelah server di-restart (membuktikan penyimpanan permanen sudah benar).

## Yang tidak bisa saya lakukan dari sini
Saya tidak bisa membuat akun hosting atau memasang server atas nama Anda. Kalau ada langkah yang tidak cocok dengan tampilan layanannya, kirim tangkapan layar dan saya bantu cari jalan keluarnya.
